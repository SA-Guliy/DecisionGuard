# Handoff (Short) — Next Session

## Latest update (Contour split + report reliability, today)

- Removed false methodology fatals caused by context mixing:
  - files:
    - `scripts/build_ab_report.py`
    - `scripts/build_reports.py`
  - change:
    - reports now separate:
      - `current AB contour` (metric/goal from AB artifact + current AB contract metric if present),
      - `next experiment contour` (Doctor portfolio target).
    - alignment now has two independent statuses:
      - `current_alignment_status` (fatal only when current AB contract truly mismatches AB primary metric),
      - `next_vs_current_ab_status` (informational: can be `DIFFERENT` and is not fatal by itself).

- Added full observed metrics table inside each goal contour (including guardrails):
  - `DECISION_CARD_V2.md`
  - `decision_card.md`
  - `AB_STAT_REPORT.md`
  - corresponding JSON artifacts (`decision_card_v2.json`, `ab_v2.json`) now include `observed_metrics` per goal.

- Hardened AB artifact selection in report builder:
  - `scripts/build_reports.py` now falls back to `data/ab_reports/{run_id}_*_ab.json` if run-config experiment id path is missing.

- Updated `run_all` AB default metric:
  - file: `src/run_all_cli.py`
  - changed default `--ab-primary-metric` from `aov` to `writeoff_rate_adj`
  - reason: default behavior now matches the primary spoilage/writeoff objective and reduces accidental goal/metric drift.

- Rebuilt fresh reports after fixes:
  - `v13_agent_prod_011`
  - `v13_agent_prod_013`
  - both now show:
    - `ab_status: INCONCLUSIVE` (instead of false `INVALID_METHODS` due contour mixing),
    - `current_alignment_status: PASS_CURRENT_AB`,
    - `next_vs_current_ab_status: DIFFERENT` (expected when next experiment targets a different goal).

- Honest readiness blocker remains:
  - core real-LLM authenticity is still `0/3` in current artifacts for these runs (environment had no API keys in this agent session).
  - this blocks a strong “agents proved improvement” GitHub claim until a real-LLM proof run is recorded.

## Latest update (AB standard alignment, today)

- Fixed a root-cause AB preflight bug:
  - file: `scripts/run_ab_analysis.py`
  - issue: `_table_has_column(...)` used `:rel::regclass`, which SQLAlchemy did not bind correctly
  - effect: false `DATA_COLUMN_MISSING_CUSTOMER_ID`, cascading into `MISSING_ASSIGNMENT` and HOLD decisions
  - fix: switched to `CAST(:rel AS regclass)`; preflight now correctly detects `customer_id`

- Fixed Doctor local-proof stability:
  - file: `scripts/run_doctor_variance.py`
  - issue: `recommended_experiment.wash_in_days` could be `null` -> schema validation fail in local/mock path
  - fix: apply deterministic design defaults when `first_exp` lacks design fields; enforce typed values in `recommended_experiment`

- Improved design-contract observability fallback logic:
  - files:
    - `scripts/build_reports.py`
    - `scripts/make_agent_quality_report_v2.py`
    - `scripts/make_agent_quality_summary.py`
    - `scripts/build_weekly_pack.py`
  - behavior:
    - if `ab_plan[0]` is empty, use `recommended_experiment` to compute design-contract completeness/coverage/gaps
  - result:
    - current proof run (`v13_agent_prod_010`) now shows design contract complete in L1 artifacts

- Propagated AB design-contract observability into operational and weekly reports:
  - `scripts/build_reports.py`
    - now builds normalized `ab_design_contract` with safe fallbacks for old artifacts
    - injects design contract into `data/decision_cards/<run>_decision_card_v2.json`
    - adds `SECTION 0B — AB Design Contract` to `DECISION_CARD_V2.md`
    - adds design-completeness/gaps lines to `decision_card.md` and `index.md`
  - `scripts/make_agent_quality_report_v2.py`
    - Doctor quality now includes:
      - `design_contract_field_coverage`
      - `design_contract_gap_count`
      - `design_contract_gap_codes`
      - `design_contract_complete`
      - `required_design_fields`
  - `scripts/make_agent_quality_summary.py`
    - weekly doctor aggregates now include:
      - `design_contract_complete_pct`
      - `avg_design_field_coverage`
      - `top_design_gap_codes`
  - `scripts/build_weekly_pack.py`
    - `weekly_summary.md` now surfaces doctor design-contract completeness/gaps

- Implemented AB methodology standard fields in Doctor outputs (not only docs):
  - `pre_period_weeks`
  - `test_period_weeks`
  - `wash_in_days`
  - `attribution_window_rule`
  - `test_side`
  - `randomization_unit`
  - `analysis_unit`
  - `metric_semantics`
  - `surrogate_batch_id_strategy` (for writeoff-like metrics)
- Added deterministic defaults for these fields via `_default_design_fields(...)` in `scripts/run_doctor_variance.py`.
- Propagated fields into:
  - `ab_plan[*]`
  - hypothesis contract (`hypotheses[0]`)
  - `recommended_experiment`
  - `measurement_fix_plan.required_design_fields`
  - Doctor context (`data/agent_context/..._doctor_context.json`)
- Strengthened contract checks:
  - `_validate_experiment_contract(...)` now validates design fields
  - `_validate_output_contract(...)` requires these design fields in `ab_plan` and `recommended_experiment` (if present)
- Methodology selector input now includes design requirements (`pre_period/wash_in/attribution/test_side/metric_semantics`), so LLM method choice is grounded in design context.
- Updated Doctor output schema description (`configs/doctor/doctor_variance_output_schema.json`) to include new design-related fields.

Why:
- aligns execution artifacts with AB methodology standard
- removes ambiguity around attribution and experiment design
- makes outputs explainable for GitHub/defense and safer for decisioning

## What was done (and why)

### 1) Architecture cleanup / readability (core)
- `scripts/run_all.py` was refactored into explicit layers:
  - `_run_core_proof_path(...)`
    - `_run_simulation_and_foundation_steps(...)`
    - `_run_metrics_and_ab_steps(...)`
    - `_run_core_agents_and_proof_steps(...)`
  - `_run_reporting_tail(...)`
  - `_run_transparency_tail(...)`
  - `_run_security_and_reports_tail(...)`
  - `_run_eval_publish_tail(...)`
  - `main()` now mostly orchestrates runtime/env + calls these functions.
- Added `_run_py_step_specs(...)` to reduce repeated boilerplate in reporting tail.
- Added `_py(...)` and `_try_run_step(...)` helpers to reduce repeated command/warn patterns.
- Added setup helpers so `main()` is easier to explain:
  - `_run_raw_reload_if_requested(...)`
  - `_read_valid_orders_count(...)`
- Then moved CLI parser/runtime config out of `scripts/run_all.py` into:
  - `src/run_all_cli.py` (`build_run_all_parser`, `resolve_run_all_runtime_config`)
  - this reduced `run_all.py` size again while keeping logic readable
- Fixed a real regression found during critical review:
  - `python3 scripts/run_all.py --help` failed with `ModuleNotFoundError: src`
  - added project-root `sys.path` bootstrap in `scripts/run_all.py` (same pattern as other scripts)

Why:
- make `run_all.py` explainable in interview/defense
- reduce duplicate code / hidden inconsistencies
- prepare for further slimming of `scripts/`

### 2) Shared SSOT modules (to reduce duplication)
- `src/model_policy.py` — agent model routing policy
- `src/status_taxonomy.py` — statuses/errors/goal-metric mapping
- `src/paths.py` — common shared paths (kept thin)
- `src/run_output_paths.py` — run-summary output paths (separate to avoid bloating `paths.py`)
- `src/agent_llm_auth.py` — shared logic for:
  - `LLM Path Reached`
  - `Core LLM Accepted`

Why:
- one source of truth
- less drift across `run_all`, trace, friction report

### 3) Transparency / proof artifacts improved
- `AGENT_REASONING_TRACE` and `AGENT_INTERACTION_FRICTION_REPORT` now use shared LLM-auth logic.
- They clearly distinguish:
  - API reached vs
  - core LLM output accepted by validators

Why:
- honest proof of agent behavior
- easier debugging of fallback paths

### 4) L2 weekly quality summary (made more useful for agent debugging)
- `scripts/make_agent_quality_summary.py` upgraded:
  - adds `llm_authenticity` (real LLM accepted vs path reached)
  - adds normalized commander blocker codes (`hold_reason_codes_top`)
  - adds `ab_observability` (`ab_status`, `measurement_state`)
  - adds doctor methodology selection distribution
- Introduced canonical weekly outputs:
  - `reports/L2_mgmt/weekly_<YYYY_WW>/agent_quality_summary.json`
  - `reports/L2_mgmt/weekly_<YYYY_WW>/agent_quality_summary.md`
- Kept legacy alias compatibility for now:
  - `reports/L2_mgmt/<YYYY-WW>/agent_quality.{json,md}`
- `scripts/build_weekly_pack.py` now writes `weekly_agent_quality.md` as a backward-compatible alias
  pointing to canonical `agent_quality_summary.md` (instead of duplicating a separate quality report when canonical exists).

Why:
- reduce duplicate weekly reports
- keep old paths working temporarily
- shift reporting toward signals useful for debugging agent performance (not just legacy scores)

### 4) Architecture docs / discussion
- `docs/ARCHITECTURE_DISCUSSION.md` now has:
  - a simplified Mermaid architecture (discussion-first)
  - a detailed version (optional)
- `docs/GLOSSARY.md` added/expanded (SSOT, Artifact, Trace, Friction Report, etc.)
- `docs/CODE_DUPLICATION_SCREEN.md` tracks what was duplicated and what was cleaned

Why:
- align understanding fast
- support GitHub + defense explanation

## What is still left (and why)

### A) Further slim `run_all.py` (high value)
- `_run_reporting_tail(...)` is cleaner but still long.
- We already split reporting tail into helpers; next step is **slim `_run_core_proof_path(...)`**
  and (optionally) move verbose CLI parser definition out of `run_all.py`.

Why:
- easier to read and test
- clearer separation of “proof” vs “reporting”

### B) Reduce script sprawl / duplicate command orchestration (high value)
- More `scripts/*` still contain too much logic.
- Continue moving reusable logic into `src/*` (carefully, not too fragmented).

Why:
- less “forest” effect
- easier maintenance and explanation

### C) Memory between runs (important architecture gap)
- Memory registries are shown in architecture, but implementation is not yet finished.

Why:
- important for project goal (agents improving over runs)

### D) Data observability architecture (major unfinished)
- `AB input fact`
- `customer_window_features`
- richer `cohort_evidence_pack` (tenure/pre-period/preferences/transitions)

Why:
- core bottleneck for valid AB + causal reasoning

## Current status (honest)

- Core logic works.
- `main()` is much easier to defend/explain now (orchestrator shape is visible).
- `run_all.py` may still be long in line count (more named helpers), but logic is less tangled.
- `run_all.py` is now also shorter again after moving parser/runtime config to `src/run_all_cli.py`.
- We are now in **architecture cleanup + observability upgrade phase**, not “bug patch only”.
- Project is significantly more transparent than before, but still not fully cleaned:
  `run_all.py` remains big because parser + core path are still in the same file.

## Estimated remaining work (pragmatic)

### For a strong “publishable milestone” (GitHub + demo)
- ~1 focused work block (3–6 hours):
  - finish `run_all.py` slimming
  - final architecture/docs cleanup + weekly/L2 naming cleanup
  - one clean proof run + regenerated trace/friction

### For “architecture feels clean end-to-end”
- ~2–4 more work blocks:
  - deeper script thinning
  - memory registries
  - richer cohort/data artifacts
  - optional archive cleanup pass

## Priority order for next session

1. Optional size reduction: move verbose CLI parser spec out of `scripts/run_all.py` (or generate from arg-spec table)
2. Continue de-dup inside `scripts/*` by moving shared loaders/policies into `src/*`
3. Implement memory registries (minimal viable version)
4. Expand cohort evidence pack (tenure + pre-period first)
