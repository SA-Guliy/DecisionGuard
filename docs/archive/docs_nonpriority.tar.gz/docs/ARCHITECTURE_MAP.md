# Architecture Map (Current Active Path)

## Why this file exists

This project has grown through multiple iterations (`v0`, `v1`, canary/prod runs, agent experiments).
The goal of this map is to make the active architecture readable in 1-2 minutes for:

- project defense / interview walkthrough
- GitHub readers
- future refactors without breaking the core pipeline

## Project goals (business)

The active agent pipeline is built to improve 3 business goal groups while preserving guardrails:

1. Goal 1: writeoff / shrink / waste reduction
2. Goal 2: economics (AOV / GMV / GP margin)
3. Goal 3: buyers / retention / activity

## Core architecture (active path)

### Orchestrator

- `scripts/run_all.py`
  - coordinates end-to-end run
  - runs data prep / reports / agents / diagnostics
  - enforces proof-run checks (including core-agent LLM authenticity counters)

### Core agents (3)

- `scripts/run_captain_sanity_llm.py` (Agent 1: Captain)
  - QA / DQ sanity review
  - strict JSON output + SQL-safe verification suggestions
  - fast model route

- `scripts/run_doctor_variance.py` (Agent 2: Doctor)
  - experiment scientist / methodology / hypotheses
  - AB interpretation methodology selection
  - measurement fix plans when AB is not observable/valid

- `scripts/run_commander_priority.py` (Agent 3: Commander)
  - final decision + priorities + PM reasoning
  - reads Captain + Doctor + evaluator + AB + cohort evidence
  - LLM proposal is validator-gated and safety-bounded

## AB validity / methodology path (active)

- `scripts/run_ab_preflight.py`
  - validation stop before A/B statistics
  - schema/grain/assignment/join checks
  - writes human-readable preflight report + JSON

- `scripts/run_ab_analysis.py`
  - reads validated inputs and computes AB outputs
  - no silent customer->store fallback in final decision path

- `scripts/build_ab_report.py`
  - human-readable AB report
  - reads methodology from Doctor when available

## Evidence / observability path (active)

- `scripts/build_cohort_evidence_pack.py`
  - compact cohort cuts for Commander (currently spend/frequency buckets)

- `scripts/build_evidence_pack.py`
  - aggregates evidence references into a single pack

## Diagnostics / transparency path (active)

- `scripts/build_agent_reasoning_trace.py`
  - per-run trace across Captain / Doctor / Commander
  - distinguishes:
    - `LLM Path Reached`
    - `Core LLM Accepted`

- `scripts/build_agent_interaction_friction_report.py`
  - cross-run handoff friction report
  - tracks fallback reasons, validation issues, model/provenance signals

- `scripts/build_ab_failure_registry.py`
  - cross-run AB failure taxonomy (counts by root cause)

## Shared code (active, refactor target)

- `src/llm_client.py`
  - backend routing (`groq`, `ollama`, `auto`, `local_mock`)

- `src/model_policy.py`
  - role -> model mapping (Captain / Doctor / Commander)
  - active source of truth for Groq model policy

- `src/llm_contract_utils.py`
  - JSON parsing / coercion helpers for LLM contracts

- `src/decision_contract.py`
  - decision schema validation helpers

## Main artifact directories (active)

- `data/` -> machine-readable artifacts (agent outputs, logs, AB, diagnostics)
- `reports/L1_ops/` -> operator-facing markdown reports
- `reports/L2_mgmt/` -> management summaries
- `reports/L3_exec/` -> exec summaries

## Cleanup strategy (agreed direction)

The next refactor steps should optimize for explainability and maintainability:

1. Thin `scripts/` entrypoints
   - CLI + orchestration only
   - move reusable logic to `src/`

2. Single-source policy modules
   - model policy
   - status/error taxonomy
   - artifact paths

3. Archive, do not delete (first)
   - move inactive/legacy code to a clearly labeled archive path
   - keep index/manifest so history is still understandable

4. Preserve proof-run integrity
   - every cleanup step followed by smoke run + trace/friction regeneration

## What is still confusing (known debt)

- duplicated status/method mappings across scripts
- mixed semantics of "current AB interpretation" vs "next experiment plan"
- legacy directories (`v0/`, `v1/`, old logs/reports) clutter visual scan
- too much artifact-path string construction inside scripts

