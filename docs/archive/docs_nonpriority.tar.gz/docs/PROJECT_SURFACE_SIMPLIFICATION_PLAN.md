# Project Surface Simplification Plan

## Why (goal-aligned)

This project is not only about working logic. It must be:
- easy to explain in interview / defense
- easy to read on GitHub
- visibly structured (few clear entrypoints, clear ownership)
- safe and transparent (proof artifacts remain, but clutter is controlled)

The problem today is not just `run_all.py`. The overall project surface is too wide:
- too many top-level scripts
- too many generated outputs visible at once
- too many working docs mixed with canonical docs

## Current Surface (quick audit)

- `scripts/*.py` (top-level): `50`
- `scripts/**/*.py` total: `53`
- `src/**/*.py`: `13`
- `docs/*.md`: `18`
- `reports/L1_ops/**/*`: `654` entries (generated artifacts, growing)

## Important Principle (to avoid wrong optimization)

We are **not** optimizing for “smallest file count” or “smallest line count”.

We are optimizing for:
- fewer duplicated decisions
- fewer confusing entrypoints
- clearer separation:
  - runtime pipeline
  - agent logic
  - reporting/proof
  - evals
  - admin/maintenance

## Canonical Project Surface (target)

### 1) Human-facing core entrypoints (small set)

These should be easy to find and explain first:

- `scripts/run_all.py` — full orchestrator
- `scripts/run_captain_sanity_llm.py` — Agent 1
- `scripts/run_doctor_variance.py` — Agent 2
- `scripts/run_commander_priority.py` — Agent 3
- `scripts/run_ab_preflight.py` — AB readiness gate
- `scripts/run_ab_analysis.py` — AB analysis
- `scripts/build_reports.py` — human-facing report bundle
- `scripts/build_agent_reasoning_trace.py` — per-run transparency proof
- `scripts/build_agent_interaction_friction_report.py` — cross-run agent friction proof

These are the scripts a reviewer should understand first.

### 2) Support / reporting / eval scripts (keep, but not front-and-center)

Examples:
- `scripts/build_*` (MBR, weekly pack, exec brief, hubs, evidence packs)
- `scripts/eval_agents_v2.py`
- `scripts/run_adversarial_eval_suite.py`
- `scripts/run_agent_value_eval.py`
- `scripts/make_agent_quality_report.py`
- `scripts/check_contracts.py`
- `scripts/check_decision_contracts.py`
- `scripts/pre_publish_audit.py`
- `scripts/verify_acceptance.py`

These are useful, but should be grouped conceptually in docs and eventually in folders/modules.

### 3) Admin / maintenance / one-off scripts (review for archive or move)

Examples:
- `scripts/admin_*`
- `scripts/archive_*_housekeeping.py`
- `scripts/render_architecture_diagram.py` (developer tooling)
- `scripts/run_ensemble.py` (needs role clarification)
- `scripts/update_active_experiments_registry.py` (ownership clarification)

These are not “first-read” project flow and should not visually dominate.

## Output / Docs Surface (also part of architecture clarity)

### Keep visible (canonical docs)

- `README.md` (project overview)
- `docs/ARCHITECTURE_DISCUSSION.md` (discussion / visual)
- `docs/ARCHITECTURE_MAP.md` (technical map)
- `docs/GLOSSARY.md`
- `docs/ab_data_contract_v1.md`
- `docs/ab_methodology_spec.md`
- `configs/contracts/*.json` and `configs/doctor/*.json` (machine-readable contracts/schemas; not docs)

### Working docs (useful, can be archived)

- `docs/archive/ARCH_AUDIT_PASS1_TOP_DOWN_BUILT.md`
- `docs/archive/ARCH_AUDIT_PASS2_BOTTOM_UP_REVERSE.md`
- `docs/archive/ARCH_REFACTOR_BACKLOG.md`
- `docs/archive/CODE_DUPLICATION_SCREEN.md`
- `docs/HANDOFF_NEXT_SESSION_SHORT.md`
- some methodology notes/playbooks (after consolidation)

### Generated reports (do not treat as canonical docs)

- `reports/L1_ops/**` are runtime artifacts (proof, diagnostics, ops outputs)
- keep them for evidence, but document them as generated outputs
- avoid mixing them conceptually with architecture docs

## New Rule for Adding Files (to stop sprawl)

Before adding a new file, one of these must be true:

1. It becomes a shared SSOT used by **2+ scripts**
2. It clearly separates a stable boundary (e.g. `cli`, `taxonomy`, `paths`)
3. It reduces cognitive load for the reader (not just moves lines around)

If none apply:
- keep logic local
- or refactor an existing module instead of creating another file

## Next Cleanup Steps (practical)

### Step A — Script inventory labeling (low risk, high clarity)
- create a `scripts/README.md` with categories: ✅ done
  - core
  - agents
  - AB
  - reports/proof
  - evals
  - admin/maintenance

### Step B — Reduce visible clutter in root (low risk)
- move developer-only diagram test outputs (e.g. `architecture_test.*`) into a dev/archive folder ✅ done
- move reference screenshots / temp exports out of root ✅ done
- keep final `architecture.png/svg` only (still true; `architecture.dot` remains optional)

### Step C — Consolidate support scripts by domain (careful)
- move shared report/eval helper logic to `src/*`
- keep script entrypoints thin

### Step D — Archive non-core docs after consolidation
- keep canonical docs visible
- move working notes/history docs into `docs/archive/`

## Success Criteria (for defense / GitHub)

A reviewer should be able to open the repo and understand in ~1 minute:
- where the 3 agents live
- where AB validity gates live
- where human approval lives
- where proof / transparency artifacts live
- which files are core vs support vs generated
