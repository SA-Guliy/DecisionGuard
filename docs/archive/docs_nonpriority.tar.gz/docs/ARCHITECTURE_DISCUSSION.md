# Architecture Discussion (Preview)

Этот файл нужен, чтобы мы могли обсуждать архитектуру визуально в Markdown-preview.

Как открыть как картинку/схему:
- VS Code / Cursor: `Cmd+Shift+V` (Open Preview)
- или `Open Preview to the Side`

## 1) SVG Preview (current generated diagram, detailed)

![Architecture Preview](../architecture.svg)

## 2) Mermaid (simple, discussion-first)

```mermaid
flowchart TD
  classDef agent fill:#EEF4FF,stroke:#4F7ECF,stroke-width:2px,color:#000;
  classDef db fill:#F7F8FB,stroke:#6B7280,stroke-width:2px,color:#000;
  classDef warning fill:#FFF8DB,stroke:#B08900,stroke-width:2px,color:#000;
  classDef output fill:#EEFCEF,stroke:#2F855A,stroke-width:2px,color:#000;
  classDef hitl fill:#FFF6CC,stroke:#B58900,stroke-width:2px,color:#000;
  classDef diag fill:#F4EEFF,stroke:#7C3AED,stroke-width:2px,color:#000;

  DB[(Postgres / Retail Data)]:::db

  subgraph ENGINE ["Agent Decision Engine (Python • Groq • ReAct)"]
    direction TB
    
    subgraph AGENTS ["Core Decision Pipeline"]
      direction LR
      C[Agent 1: Captain<br/>Data Verifier]:::agent --> D[Agent 2: Doctor<br/>Experiment Designer]:::agent --> CMD[Agent 3: Commander<br/>Gatekeeper]:::agent
    end
    
    subgraph MATH ["Experimentation & Governance"]
      direction LR
      PRE[AB Preflight]:::db -->|PASS| ANA[AB Analysis & Stats]:::db
      COH[Cohort Evidence Pack]:::db
      FIX[Measurement Fix Plan (P2)]:::warning
    end
    
    ANA -->|Stats + CI| D
    COH -->|Cohort evidence| CMD
    PRE -.->|Fail: Grain / Schema / Assignment| FIX
    ANA -.->|Fail: Invalid methods / mismatch| FIX
    FIX -.->|Blocks / Triggers Re-run| CMD
  end

  HITL{HITL Approval<br/>Human Review}:::hitl
  PROD((Retail Prod Sandbox)):::output
  OUT[Reports / Decision Cards / MBR]:::db
  EVALS[Agent Evals<br/>quality / value / adversarial / contracts]:::diag
  TRACE[AGENT_REASONING_TRACE]:::diag
  FRICTION[AGENT_INTERACTION_FRICTION_REPORT]:::diag

  DB ==>|Metrics| C
  DB ==>|Logs + Assignment| PRE
  DB ==>|Customer-grain facts| COH
  
  CMD ==>|Decision Proposal| HITL
  CMD ==>|Generates| OUT
  FIX -.->|Remediation may need approval| HITL
  HITL ==>|Approved Action| PROD

  C -.-> TRACE
  D -.-> TRACE
  CMD -.-> TRACE
  C -.-> EVALS
  D -.-> EVALS
  CMD -.-> EVALS
  ANA -.-> EVALS
  EVALS -.-> FRICTION
  CMD -.-> FRICTION
```

## 3) Mermaid (detailed, optional)

<details>
<summary>Open detailed version (more arrows, more implementation detail)</summary>

```mermaid
flowchart LR
  %% Main pipeline (what happens when everything works)
  D["Data Layer<br/>(Postgres / SQL + AB artifacts)"]
  A1["Agent 1 — Captain<br/>(Data Verifier)"]
  A2["Agent 2 — Doctor<br/>(Experiment Designer)"]
  A3["Agent 3 — Commander<br/>(Decision Gatekeeper)"]
  H["HITL Approval"]
  P["Retail Prod Sandbox"]

  D -->|"DQ + evidence inputs"| A1
  A1 -->|"sanity / data quality signals"| A2
  A2 -->|"hypothesis + methodology + plan"| A3
  A3 -->|"decision proposal + risks"| H
  H -->|"approved actions only"| P

  %% AB validity lane (feeds Doctor/Commander)
  PF["AB Preflight"]
  AB["AB Analysis"]
  CE["Cohort Evidence Pack"]
  PF --> AB
  D --> PF
  D --> CE
  AB -->|"validity + stats"| A2
  CE -->|"cohort evidence"| A3

  %% Measurement remediation lane (P2)
  MFP["Measurement Fix Plan (P2)<br/>(when AB is unobservable / invalid)"]
  PF -.->|"fail / schema / join / assignment"| MFP
  AB -.->|"invalid methods / mismatch"| MFP
  A2 -.->|"doctor.measurement_fix_plan"| MFP
  MFP -.->|"re-run requirements"| A3
  MFP -.->|"human approval for remediation"| H

  %% Transparency + evaluation (sidecar, not main line)
  T["AGENT_REASONING_TRACE<br/>(per-run transparency)"]
  F["AGENT_INTERACTION_FRICTION_REPORT<br/>(cross-run frictions)"]
  E["Agent Evals<br/>(quality / value / adversarial / contracts)"]
  R["AB Failure Registry"]

  A1 -.-> T
  A2 -.-> T
  A3 -.-> T
  A3 -.-> F
  PF -.-> R
  AB -.-> R
  A1 -.-> E
  A2 -.-> E
  A3 -.-> E
  AB -.-> E
  E -.-> F

  %% Runtime/stack (collapsed into one block to reduce noise)
  S["Runtime Stack<br/>Python • Groq LLM • ReAct • Validators • Provenance"]
  S -.-> A1
  S -.-> A2
  S -.-> A3
  S -.-> T
  S -.-> F

  %% Styling (simple and presentation-first)
  classDef agent fill:#EAF3FF,stroke:#3B82F6,color:#1F2937,stroke-width:1.5px;
  classDef doctor fill:#EAFBF3,stroke:#22A06B,color:#1F2937,stroke-width:1.5px;
  classDef commander fill:#FFF2E8,stroke:#DD6B20,color:#1F2937,stroke-width:1.5px;
  classDef gate fill:#FFF7D6,stroke:#B58900,color:#1F2937,stroke-width:1.5px;
  classDef sandbox fill:#FFECEC,stroke:#C53030,color:#1F2937,stroke-width:1.5px;
  classDef data fill:#F3F7FF,stroke:#4A5568,color:#1F2937,stroke-width:1.2px;
  classDef infra fill:#EFFFF6,stroke:#2F855A,color:#1F2937,stroke-width:1.2px;
  classDef diag fill:#F4EEFF,stroke:#6B46C1,color:#1F2937,stroke-width:1.2px;
  classDef fallback fill:#FFF6F6,stroke:#C53030,color:#1F2937,stroke-width:1.2px;
  classDef plan fill:#FFFBEA,stroke:#B58900,color:#1F2937,stroke-width:1.2px;

  class A1 agent;
  class A2 doctor;
  class A3 commander;
  class H gate;
  class P sandbox;
  class D,PF,AB,CE data;
  class S infra;
  class T,F,R,E diag;
  class MFP plan;
```

</details>

## 4) Что проверить вместе (быстрая синхронизация)

1. Правильно ли отражены роли 3 агентов?
2. Нужен ли отдельный блок `Narrative/Explainer` на схеме или пока оставляем вне core?
3. Хотим ли показать `Human-in-the-loop` как обязательный gate только для high-impact actions?
4. Добавляем ли на схему `memory registries` как отдельный блок (между runs)?
5. Показываем ли `AB input fact / customer_window_features` отдельно (следующий архитектурный шаг)?
6. `Measurement Fix Plan (P2)` оставляем как Doctor-owned блок или делаем совместный Doctor+Commander remediation lane?
7. `Agent Evals` показываем как optional/reporting tail (как сейчас) или как обязательную часть proof-run?
8. Нужно ли отдельно показать `LLM API degraded/fallback mode`, или это оставить только в `trace/friction`, чтобы не перегружать главную схему?
