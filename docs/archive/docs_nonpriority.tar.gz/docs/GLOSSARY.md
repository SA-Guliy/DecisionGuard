# Project Glossary (Living)

This is a living glossary for project terminology.
Add terms here whenever something is unclear, so you do not need to ask the same thing twice.

## Core terms

### `SSOT` (Single Source of Truth)

One canonical place where a rule or mapping is defined.

Why it matters:
- reduces duplicate logic
- prevents inconsistencies across scripts
- makes code easier to explain in a defense/interview

Examples in this project:
- `src/model_policy.py` = SSOT for agent model routing
- `src/status_taxonomy.py` = SSOT for key status/error sets and `goal_from_metric`
- `src/paths.py` = SSOT for common artifact paths

### `Artifact`

A file produced by a pipeline step or agent (usually JSON or Markdown) that captures output/evidence.

Examples:
- `data/agent_reports/<run_id>_doctor_variance.json`
- `reports/L1_ops/<run_id>/AGENT_REASONING_TRACE.md`
- `data/ab_preflight/<run>_<exp>_preflight.json`

Why it matters:
- reproducibility
- debugging
- auditability (you can trace what happened in a run)

### `Trace` / `Reasoning Trace`

Отчет, который показывает цепочку рассуждений и handoff между агентами по одному `run_id`.

В нашем проекте:
- `reports/L1_ops/<run_id>/AGENT_REASONING_TRACE.md`

Что там обычно видно:
- какие модели реально использовались
- где был fallback
- `LLM Path Reached` vs `Core LLM Accepted`
- как Captain -> Doctor -> Commander передавали решение/ограничения

Зачем нужен:
- для отладки логики между агентами
- для доказательной базы на защите/собесе
- чтобы не верить “на слово”, а видеть артефакт

### `Pipeline`

The ordered sequence of steps run for one `run_id` (simulation, DQ, metrics, AB, agents, reports, etc.).

Main orchestrator:
- `scripts/run_all.py`

### `Orchestrator`

The script that coordinates multiple steps in order and passes shared settings (backend, run_id, flags).

In this project:
- `scripts/run_all.py`

### `Agent`

A role-specific decision component in the system.

Core 3 agents:
- `Captain` (Agent 1): QA / sanity checks
- `Doctor` (Agent 2): experiment scientist / methodology / hypotheses
- `Commander` (Agent 3): final decision / trade-offs / PM priorities

### `HITL` (Human in the Loop)

A safety/decision pattern where a human reviews or approves before high-impact actions.

In this project:
- agents can reason and propose actions
- hard gates and human review prevent unsafe rollout

## LLM / reasoning terms

### `LLM Path Reached`

The code successfully called a real LLM backend (e.g., Groq) and received a response.

This does **not** mean the output was accepted for core decisioning.

### `Core LLM Accepted`

The LLM response passed schema/validator/contract checks and was used as the agent’s authoritative core output (not fallback).

This is stricter than "LLM path reached".

### `Fallback`

A backup path used when the primary path fails.

Types of fallback in this project:
- backend fallback (e.g., API unavailable)
- schema fallback (LLM output invalid JSON/contract)
- deterministic fallback (safe rule-based method/decision)

### `Provenance`

Metadata that explains where a result came from and how it was produced.

Examples:
- which model was used
- whether fallback happened
- fallback reason
- whether remote API was allowed

Why it matters:
- transparency
- debugging
- proof that the system did (or did not) use real LLM reasoning

### `Friction Report` (Agent Interaction Friction Report)

Сводный отчет по трениям между агентами на наборе раннов (не один run, а много).

В нашем проекте:
- `reports/L1_ops/AGENT_INTERACTION_FRICTION_REPORT.md`

Что показывает:
- где агенты расходятся в решениях
- где LLM path есть, но core output отклонен валидатором
- где чаще всего fallback/contract проблемы
- распределение по моделям / причинам / статусам

Зачем нужен:
- найти системные паттерны ошибок
- понять, что сломано в архитектуре handoff
- не путать единичный сбой с массовой проблемой

### `Schema` / `Contract`

A strict expected structure for input/output data (fields, types, required keys, allowed values).

Why it matters:
- prevents brittle downstream failures
- makes agent outputs machine-usable
- improves safety (reject malformed or hallucinated structures)

## AB testing / methodology terms

### `AB Preflight`

A validation step run before AB statistics to verify the experiment is measurable and data contracts are satisfied.

In this project:
- `scripts/run_ab_preflight.py`

Typical checks:
- required columns exist (e.g., `customer_id`)
- assignment exists
- join path is valid
- experiment/unit assumptions are supportable

### `Measurement State`

Whether the system can legitimately measure the experiment outcome.

Common values:
- `OBSERVABLE`
- `UNOBSERVABLE`
- `BLOCKED_BY_DATA`

### `AB Status`

Status describing AB analysis validity/condition (e.g., assignment missing, methods invalid, etc.).

Examples:
- `MISSING_ASSIGNMENT`
- `METHODOLOGY_MISMATCH`
- `INVALID_METHODS`
- `UNDERPOWERED`

### `Δ abs` (absolute lift)

Абсолютная разница между `Treatment` и `Control`:
- `Δ abs = Treatment - Control`

### `Δ rel` (relative lift)

Относительная разница (uplift) относительно `Control`:
- `Δ rel = (Treatment - Control) / Control`

### `pp` (percentage points)

Процентные пункты (а не проценты).

Пример:
- `4.6% -> 3.9% = -0.7pp`

### `CI95` (95% confidence interval)

95% доверительный интервал для эффекта.
В AB-отчетах читается вместе с `Δ abs / Δ rel` и `p-value`.

### `MDE` (Minimum Detectable Effect)

Минимальный эффект, который тест способен надежно заметить при заданных:
- `alpha`
- `power`
- размере выборки
- дисперсии

### `SRM` (Sample Ratio Mismatch)

Проверка, что распределение по группам (`control/treatment`) соответствует плану аллокации (например, 50/50).

### `ITT` (Intention-To-Treat)

Подход анализа “по назначению в группу”:
- объект остается в назначенной группе,
- даже если фактическое воздействие выполнено не полностью.

### `Goal/Metric Alignment`

Check that the hypothesis target goal matches the AB primary metric’s goal family.

Example:
- hypothesis targets Goal1 (writeoff)
- AB primary metric is `aov` (Goal2)
- this is a misalignment and should block/stop decisioning

### `Guardrail`

A metric that must stay within safe bounds while optimizing another metric.

Examples:
- `fill_rate_units`
- `gp_margin`
- `gmv`
- `oos_lost_gmv_rate`

## Engineering / architecture terms

### `Legacy`

Не обязательно "плохой" или "ненужный" код/артефакт.

В этом проекте `legacy` обычно значит:
- более старый слой/формат
- который частично заменен новым слоем
- но может еще существовать ради совместимости/перехода

Важно:
- `legacy` != автоматически удалить
- сначала проверяем, кто читает артефакт/скрипт и зачем он нужен

### `Deprecation` (депрекация)

Управляемый вывод из использования.

Обычно это:
1. оставить новый канонический путь
2. пометить старый путь как deprecated
3. убрать чтение/генерацию старого слоя после проверки зависимостей

### `Canonical` (канонический)

Главный источник правды для конкретного типа данных/отчета.

Пример:
- `AGENT_SCORECARD.md` + `agent_quality_v2.json` могут быть каноникой для agent quality v2
- старый `agent_quality.json` (v1) может быть legacy-слоем

### `Taxonomy` (status/error taxonomy)

A standardized set of categories and codes used consistently across the project.

Example:
- status families (`DATA_SCHEMA`, `METHOD`, `CONTRACT`)
- error codes (`DATA_COLUMN_MISSING_CUSTOMER_ID`)

Why it matters:
- comparable diagnostics across scripts
- clearer reports
- easier refactoring

### `Копирование кода` (copy-paste)

Когда один и тот же кусок логики вставляют в несколько файлов вручную.

Проблема:
- правишь в одном месте, забываешь в другом
- логика начинает расходиться "почти одинаково"
- сложно понять, где настоящий источник истины

Пример плохого паттерна в нашем проекте (что чистим):
- одинаковые правила подсчета `LLM Path Reached` / `Core LLM Accepted` в нескольких скриптах

### `Импортирование` (import shared module)

Когда общую логику выносят в отдельный модуль и подключают через `import`.

Плюсы:
- одна правка применяется везде
- меньше дублей
- код короче и читаемее
- проще объяснять архитектуру на собесе/защите

Пример в нашем проекте:
- `src/agent_llm_auth.py` — общая логика аутентичности LLM для `run_all`, `AGENT_REASONING_TRACE`, `friction report`

### `Top-down pass` (architecture audit)

Reviewing the system from the orchestrator downward:
- how steps are wired
- what files exist
- who owns what logic

In our current process:
- "how it was built", not "how it should work"

### `Bottom-up pass` (reverse architecture audit)

Reviewing the system from outputs/reports backward to the code that produced them.

This is how we detect:
- duplicate logic
- hidden fallbacks
- overwritten outputs
- broken ownership and source-of-truth issues

### `Legacy` / `Archive`

Older code/artifacts/history that may be useful for reference but should not clutter the active architecture.

Rule we agreed:
- archive first, delete later

## Notes

- If a term is unclear, add it here with a short example from this project.
- Prefer project-specific definitions (not textbook-only definitions).
