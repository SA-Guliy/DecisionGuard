# Archive & Cleanup Plan (Safe Refactor)

## Goal

Make the repository understandable "at a glance" without breaking the active pipeline.

## Rule

Archive first, delete later.

- Move inactive/legacy code to archive paths only after confirming no active imports/usages.
- Keep a manifest of what moved and why.
- Regenerate core reports after each move (`AGENT_REASONING_TRACE`, friction report, AB failure registry).

## What we optimize for

- defense/interview readability
- GitHub onboarding clarity
- lower risk of accidental regression
- easier reasoning about agent architecture

## Phase 1 (now) — zero-risk cleanup

- Centralize model routing policy (`src/model_policy.py`) ✅
- Add architecture map (`docs/ARCHITECTURE_MAP.md`) ✅
- Stop adding new logic into duplicated script helpers
- Identify archive candidates (no moves yet)

## Phase 2 — safe archive candidates (review before move)

Likely candidates to move out of top-level navigation:

- `v0/` (historical version snapshots)
- `v1/` (historical version snapshots)
- ad-hoc top-level temp files (for example `tmp_archived_chat_messages.tsv`) if not required for runtime
- non-runtime binary artifacts/screenshots in top-level root

Notes:
- Do not move anything under `scripts/`, `src/`, `docs/`, `configs/`, `sql/`, `reports/`, `data/` without dependency check.

## Phase 3 — code structure cleanup (active code)

- Thin `scripts/` entrypoints
  - move reusable logic to `src/`
- Centralize artifact path builders
- Centralize status/error taxonomies
- Remove duplicated goal/metric mapping helpers
- Split "current AB interpretation" vs "next experiment design" contracts clearly

## Proposed archive structure

- `archive/legacy_code/`
- `archive/legacy_docs/`
- `archive/tmp/`
- `archive/INDEX.md` (what moved, when, why, and replacement path)

## Acceptance check after each cleanup step

1. `python3 -m py_compile` on touched files
2. regenerate `AGENT_REASONING_TRACE` for a known run
3. regenerate `AGENT_INTERACTION_FRICTION_REPORT`
4. verify no import/runtime path breakage

