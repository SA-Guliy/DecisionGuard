# Agent Scoring Spec (P0)

This document defines how agent quality is scored in a deterministic, artifact-only way.

## Scope

- Script: `scripts/run_agent_value_eval.py`
- Output JSON: `data/agent_eval/<run_id>_agent_value_eval.json`
- Output MD: `reports/L1_ops/<run_id>/AGENT_VALUE_SCORECARD.md`

## Why these weights

Weights prioritize business value and safety over verbosity:

- Doctor is dominated by AB outcome readiness and experiment quality.
- Narrative is dominated by grounding and action linkage.
- Commander is dominated by alignment with Evaluator and risk blocking.
- Captain is dominated by issue coverage and evidence quality.

## Captain

| KPI | Meaning | Weight/Formula | Source |
|---|---|---|---|
| `issue_coverage` | Captures critical DQ/ops issues | `+0.35` | captain JSON |
| `evidence_density` | Issues include concrete evidence | `+0.20` | captain issues |
| `approved_realism_fixes_count` | Real fixes accepted | `+0.20 * norm` | governance approvals |
| `safety` | No unsafe behavior | `+0.15` | captain eval metrics |
| `false_positive_rate_est` | Noise penalty | `-0.10` | captain issues |

## Doctor

| KPI | Meaning | Weight/Formula | Source |
|---|---|---|---|
| `ab_success_rate` | Valid measurable AB progression | `+0.50` | evaluator |
| `methodology_completeness` | Hypothesis + evidence + falsifiability | `+0.15` | doctor portfolio |
| `approved_by_commander_count` | Governance conversion | `+0.10` | approvals |
| `guardrail_awareness` | Recognizes trade-offs | `+0.10` | metrics + reasons |
| `portfolio_diversity_score` | Diverse levers/targets | `+0.10` | doctor portfolio |
| `unique_hypotheses_count` | Non-duplicate hypotheses | `+0.05 * norm` | doctor portfolio |
| `measurement_fix_plan_present` | Value even when unobservable | `+0.05` | doctor output |
| `underpowered_rate` | Penalize weak evidence | `-0.10` | evaluator/ab |
| `mismatch_rate` | Penalize methodology mismatch | `-0.20` | evaluator/ab |

Notes:
- `review_pending_count` prevents penalizing Doctor when governance review is missing.
- `flagged_metric_alignment_status` can be `N/A` when no flagged metrics exist upstream.

## Commander

| KPI | Meaning | Weight/Formula | Source |
|---|---|---|---|
| `decision_alignment_with_evaluator` | Decision contract integrity | `+0.35` | evaluator + commander |
| `blocked_bad_experiments` | Safety blocking effectiveness | `+0.25` | adversarial + decision |
| `guardrail_retention` | Keeps guardrails healthy | `+0.20` | metrics |
| `portfolio_win_rate` | Portfolio conversion to rollout candidate | `+0.20` | commander/evaluator |

## Narrative Analyst

| KPI | Meaning | Weight/Formula | Source |
|---|---|---|---|
| `grounded_claim_rate` | Claims grounded in evidence | `+0.40` | validation |
| `top_delta_coverage` | Covers major metric shifts | `+0.25` | claims |
| `causal_chain_completeness` | Required claim fields present | `+0.20` | claims |
| `explanation_uniqueness` | Avoid repeated template reasoning | `+0.15` | evidence/cause signatures |
| `evidence_refs_to_actions_rate` | Claims linked to actions | gate signal | claims + score |

Anti-template controls:
- `evidence_pattern_uniqueness_rate`
- `cause_signature_uniqueness_rate`

## System score

`final_score = 0.40*business_value + 0.30*reasoning_quality + 0.20*safety + 0.10*reporting_quality`

Also emitted:
- `replaceable_by_python`:
  - `true` if `grounded_claim_rate < 0.7`
  - OR (`unique_hypotheses_count < 2` AND no measurement fix plan)

## Anti-gaming notes

- Raw counts alone do not increase score.
- Missing observability leads to penalties or HOLD states.
- Narrative must reference action/governance traces to score well.
