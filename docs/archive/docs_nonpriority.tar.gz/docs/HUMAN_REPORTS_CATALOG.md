# Human Reports Catalog

## Quick Entry Points

1. Global hub (all runs):
- `human_reports/README.md`

2. One run pack (example):
- `human_reports/L1/v13_agent_prod_013/index.md`

3. Native run index (inside L1):
- `reports/L1_ops/v13_agent_prod_013/index.md`
- `reports/L1_ops/v13_agent_prod_013/DEMO_INDEX.md`

## L1 (Run-Level, human-readable)

Core decisioning:
- `reports/L1_ops/<run_id>/decision_card.md`
- `reports/L1_ops/<run_id>/DECISION_CARD_V2.md`
- `reports/L1_ops/<run_id>/AB_STAT_REPORT.md`
- `reports/L1_ops/<run_id>/goal_scorecard.md`
- `reports/L1_ops/<run_id>/RETAIL_MBR.md`
- `reports/L1_ops/<run_id>/MBR_SUMMARY.md`

Agent transparency:
- `reports/L1_ops/<run_id>/AGENT_REASONING_TRACE.md`
- `reports/L1_ops/<run_id>/agent_effectiveness.md`
- `reports/L1_ops/<run_id>/agent_scorecard.md`
- `reports/L1_ops/<run_id>/AGENT_SCOREBOARD.md`
- `reports/L1_ops/<run_id>/AGENT_VALUE_SCORECARD.md`

Causal / data realism:
- `reports/L1_ops/<run_id>/CAUSAL_EXPLANATION.md`
- `reports/L1_ops/<run_id>/CAUSAL_EXPLANATION.en.md`
- `reports/L1_ops/<run_id>/synthetic_bias.md`
- `reports/L1_ops/<run_id>/evidence_pack.md`

Visuals/tables:
- `reports/L1_ops/<run_id>/charts/*.png`
- `reports/L1_ops/<run_id>/metrics_table.csv`
- `reports/L1_ops/<run_id>/mbr_kpi.csv`

## L1 (Cross-run)

- `reports/L1_ops/AGENT_INTERACTION_FRICTION_REPORT.md`
- `reports/L1_ops/AB_FAILURE_REGISTRY.md`
- `reports/L1_ops/CRITICAL_REPORTING_AUDIT.md`
- `reports/L1_ops/AGENT_ARCHITECTURE_AUDIT.md`

## L2 Management

- `reports/L2_mgmt/weekly_<YYYY_WW>/agent_quality_summary.md`
- `reports/L2_mgmt/weekly_<YYYY_WW>/weekly_summary.md`
- Legacy aliases:
  - `reports/L2_mgmt/<YYYY-WW>/agent_quality.md`
  - `reports/L2_mgmt/<YYYY-WW>/agent_quality.json`

## L3 Exec

- `reports/L3_exec/exec_brief.md` (when generated)

## How to regenerate hub

- One run:
  - `python3 scripts/build_human_reports_hub.py --run-id <run_id>`
- All runs:
  - `python3 scripts/build_human_reports_hub.py`

