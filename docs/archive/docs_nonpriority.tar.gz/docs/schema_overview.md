# Schema Overview (RAW + STEP1)

This file is the single source of truth for where things live and which columns exist.

## Locations
- Step 0 generator: `generate_raw.py`
- RAW loader: `scripts/load_raw.py`
- RAW schema (DDL): `sql/schema_raw.sql`
- Step 1 schema (admin DDL): `v1/sql/schema_step1.sql`
- Step 1 V1.3 migration (admin DDL): `v1/sql/migrations/002_step1_lot_competitor_upgrade.sql`
- Step 1 run registry (admin DDL): `v1/sql/run_registry.sql`
- Step 1 simulation: `v1/src/run_simulation_v1.py`
- Step 1 metrics: `v1/sql/metrics_v1.sql`
- RAW checks: `sql/check_raw.sql`
- Step1 checks: `v1/sql/check_step1.sql`
- DQ checks: `v1/sql/dq/dq_checks.sql`
- DQ clean views: `v1/sql/dq/dq_views.sql`
- Runtime pipeline: `scripts/run_all.py`
- Admin-only views setup: `scripts/admin_setup_views.py`

## RAW schema (Postgres, schema = raw)

### raw.raw_categories
- category_id, category_name, storage_type, perishable_policy

### raw.raw_products
- product_id, product_name
- category_id, category_name, storage_type, unit
- substitute_group_id
- is_perishable, expiry_days
- list_price, unit_cogs, max_discount_pct
- weight_kg, popularity_weight

### raw.raw_customers
- customer_id, customer_segment, activity_weight, initial_status, home_store_id

### raw.raw_day_scenarios
- date, season
- is_weekend, is_holiday, is_preholiday
- weather_bad, local_event
- scenario_type, intensity, affected_store

### raw.raw_intraday_shocks
- date, store_id
- shock_start_ts, shock_end_ts
- shock_intensity, shock_class, shock_type

### raw.raw_time_factors
- ts, date, store_id, hour, season
- is_weekend, is_holiday, is_preholiday, weather_bad, local_event
- hourly_multiplier, day_multiplier, shock_multiplier, demand_multiplier

### raw.raw_orders_stream
- ts_minute, date, store_id
- order_id, customer_id, customer_segment
- base_intent_value, budget_signal
- is_floor_fill, basket_size, units_total

### raw.raw_order_items
- order_id, product_id, requested_qty
- is_perishable, category_id
- store_id, ts_minute, date
- list_price, unit_cogs, discount_pct, unit_price
- line_gmv_requested, line_gp_requested

### raw.raw_initial_inventory
- as_of_date, store_id, product_id, initial_qty

## STEP1 schema (Postgres, schema = step1)

### step1.step1_order_items
- run_id
- order_id, product_id, store_id, ts_minute, date
- category_id, is_perishable
- requested_qty_base, requested_qty_adj, elasticity_mult, elasticity_k
- requested_qty, fulfilled_qty, lost_qty, is_oos
- competitor_price_index, competitor_mult
- list_price, discount_pct, unit_price, unit_cogs
- line_gmv_requested, line_gmv_fulfilled, lost_gmv_oos
- line_gp_requested, line_gp_fulfilled
- customer_segment

### step1.step1_orders
- run_id
- order_id, store_id, date, customer_segment
- requested_units_base, requested_units, elasticity_units_uplift
- fulfilled_units, order_fill_rate_units
- order_gmv, order_gp, order_lost_gmv_oos

### step1.step1_replenishment_log (optional)
- run_id
- date, store_id, product_id
- qty_added, inventory_after

### step1.step1_customer_daily
- run_id
- date, store_id
- rep, daily_fill_rate, churn_prob
- active_cnt, reserve_cnt, churned_today, activated_today

### step1.step1_customer_events
- run_id
- date, store_id, customer_id
- event_type, reason, value, value2

### step1.step1_writeoff_log
- run_id
- date, store_id, product_id
- lot_received_date, lot_expiry_date, pull_date
- qty_writeoff, unit_cogs, writeoff_cogs
- reason

### step1.step1_competitor_daily
- run_id
- date, store_id, category_id
- competitor_price_index, promo_flag, promo_depth

### step1.step1_run_registry
- run_id, created_at
- mode_tag, feature_flags, config_json
- qa_status, qa_updated_at, qa_summary

### step1.vw_valid_orders (view)
- `step1_orders` rows filtered by `step1_run_registry.qa_status IN ('PASS','WARN')`
- includes first-class `customer_id` from `step1.step1_orders`

### step1.vw_valid_order_items (view)
- `step1_order_items` rows filtered by approved runs
- includes calculated fields: `calc_line_gmv_fulfilled`, `calc_line_gp_fulfilled`, `calc_item_fill_rate`

### step1.vw_valid_customer_daily (view)
- `step1_customer_daily` rows filtered by approved runs
- includes calculated field: `churn_rate`

## Notes
- Step 0 is demand-only: fulfillment/OOS/waste are derived in Step 1.
- Step1 V1.3 uses FEFO for perishable lots and FIFO for non-perishable lots.
- Perishable lots are pulled before expiry by `--perishable-remove-buffer-days` and logged in `step1_writeoff_log`.
- Competitor process is exogenous and deterministic per run/category/day; enable with `--enable-competitor-prices`.
- Column order is strict for CSV load (see `scripts/load_raw.py`).
- Runtime scripts do not create schemas/tables/views; admin setup is separate.
