# Repository Tree (max depth 3)

Generated: 2026-02-20

```
.
├── README.md
├── docs
│   ├── ab_methodology_spec.md
│   ├── agent_scoring_spec.md
│   ├── methodologies_playbook.md
│   ├── metrics_contract_v1.md
│   ├── repo_tree.md
│   └── schema_overview.md
├── configs
│   ├── contracts
│   │   └── decision_contract_v1.json
│   ├── doctor
│   │   ├── doctor_variance_output_schema.json
│   │   └── doctor_variance_thresholds_v1.json
│   └── templates
│       └── active_experiments.template.json
├── scripts
│   ├── admin_fix_default_acls.py
│   ├── admin_setup_views.py
│   ├── archive_artifacts.py
│   ├── build_agent_report.py
│   ├── build_action_trace.py
│   ├── build_evidence_pack.py
│   ├── build_exec_brief.py
│   ├── build_reports.py
│   ├── build_retail_mbr.py
│   ├── build_weekly_pack.py
│   ├── check_contracts.py
│   ├── check_decision_contracts.py
│   ├── eval_agents_v2.py
│   ├── legacy
│   │   ├── build_weekly_mgmt_report.py
│   │   ├── build_weekly_report.py
│   │   └── run_pipeline.py
│   ├── make_agent_effectiveness_report.py
│   ├── make_agent_quality_report.py
│   ├── make_agent_quality_report_v2.py
│   ├── make_metrics_snapshot_v1.py
│   ├── make_realism_report.py
│   ├── run_adversarial_eval_suite.py
│   ├── run_ab_analysis.py
│   ├── run_all.py
│   ├── run_agent_governance.py
│   ├── run_agent_value_eval.py
│   ├── run_captain_sanity_llm.py
│   ├── run_commander_priority.py
│   ├── pre_publish_audit.py
│   ├── run_doctor_variance.py
│   ├── run_dq.py
│   ├── run_ensemble.py
│   ├── run_experiment_evaluator.py
│   ├── run_narrative_analyst.py
│   ├── run_synthetic_bias_audit.py
│   ├── run_security_check.py
│   ├── validate_causal_claims.py
│   ├── validate_narrative_grounding.py
│   ├── verify_acceptance.py
│   └── update_active_experiments_registry.py
├── src
│   ├── config.py
│   ├── decision_contract.py
│   ├── llm_client.py
│   └── semantic_scoring.py
├── v1
│   ├── src
│   │   └── run_simulation_v1.py
│   └── sql
│       ├── dq
│       │   ├── dq_checks.sql
│       │   ├── dq_views.sql
│       │   └── dq_views_grants.sql
│       ├── migrations
│       │   ├── 001_run_registry_upgrade.sql
│       │   ├── 002_step1_lot_competitor_upgrade.sql
│       │   ├── 003_run_registry_overwrite_audit.sql
│       │   ├── 004_step1_realism_upgrade.sql
│       │   ├── 005_step1_assignment_log.sql
│       │   └── 006_step1_assignment_enrichment.sql
│       └── schema_step1.sql
└── data
    ├── ab_reports
    ├── acceptance
    ├── agent_eval
    ├── agent_governance
    ├── agent_reports
    ├── agent_quality
    ├── decision_traces
    ├── dq_reports
    ├── eval
    ├── ensemble_reports
    ├── logs
    ├── metrics_snapshots
    ├── realism_reports
    └── security_reports
```

Notes:
- Runtime pipeline: `run_all.py` (non-admin, no DDL).
- Admin-only setup/fixes live in `scripts/admin_*.py`.
- AB evidence artifacts: `data/ab_reports/`.
- Agentic value loop artifacts:
  - action trace: `data/decision_traces/`
  - governance approvals: `data/agent_governance/`
  - adversarial suite: `data/eval/`
  - value score: `data/agent_eval/`
- L1/L2/L3 human reports are generated under `reports/`.
