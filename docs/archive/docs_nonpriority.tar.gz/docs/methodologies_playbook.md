# Darkstore Control Tower — Методики расчётов и “что это значит” (Math & Product Playbook)

Дата: 2026-02-16

Этот файл — единый справочник по методикам, которые используются в симуляции.  
**Важно:** описаны только реально реализованные алгоритмы и параметры из текущего кода.

Источники истины:
- `generate_raw.py` (V0 генератор)
- `scripts/load_raw.py` (контракт CSV + загрузка)
- `sql/schema_raw.sql` (DDL RAW)
- `v1/src/run_simulation_v1.py` (V1/V1.1 симуляция)
- `v1/sql/schema_step1.sql` (admin-only DDL Step1)
- `v1/sql/run_registry.sql` (run registry + QA status)
- `v1/sql/dq/*.sql` (DQ checks + clean views)
- `v1/sql/*.sql` (checks/metrics)
- `docs/schema_overview.md`, `v0/README1.md`, `v1/taskv1.txt`

---

## Experiment System (AB evidence-first)

С текущей версией решения Doctor/Commander опираются на артефакты эксперимента, а не только на текст:

- Assignment source: `step1.step1_experiment_assignment_log`
  - deterministic hash split (`control`/`treatment`) по `experiment_id + unit_id`.
  - параметризация: `--experiment-id`, `--experiment-unit`, `--experiment-treat-pct`, `--experiment-salt`.
  - naming compatibility: в БД каноническое поле `arm`, в отчётах поддерживается alias `variant` (`treatment -> treat`).
- AB analysis artifact: `data/ab_reports/<run_id>_<experiment_id>_ab.json`
  - primary metric uplift, CI95, p-value, sample-size gate.
- Evaluator artifact: `data/agent_reports/<run_id>_experiment_evaluator.json`
  - нормализованное решение `STOP|HOLD_NEED_DATA|HOLD_RISK|RUN_AB|ROLLOUT_CANDIDATE`.
- Commander priority читает evaluator и не поднимает решение выше evaluator.
- Единый enum решений и обязательные поля зафиксированы в `configs/contracts/decision_contract_v1.json`.
- Контроль соблюдения контракта: `scripts/check_decision_contracts.py`
  - для одного run: `data/agent_quality/<run_id>_decision_contracts.json` + `reports/L1_ops/<run_id>/decision_contract_check.md`
  - для последних N run: `data/agent_quality/decision_contracts_latest.json` + `reports/L2_mgmt/<week>/decision_contracts_latest.md`
- Предпубликационный аудит: `scripts/pre_publish_audit.py`
  - сканирует артефакты на секреты/абсолютные пути и проверяет `links.json` на битые пути.
- Synthetic bias audit: `scripts/run_synthetic_bias_audit.py`
  - читает `metrics_snapshot + dq_report`, пишет `data/realism_reports/<run_id>_synthetic_bias.{json,md}`.
- Agent governance dashboard: `scripts/build_agent_report.py`
  - пишет `reports/L1_ops/<run_id>/agent_governance.md` + `charts/agent_pass_rate.png`
  - показывает side-by-side Contract vs Execution для Captain/Doctor/Commander.
- L1 index/report builder: `scripts/build_reports.py`
  - пишет `reports/L1_ops/<run_id>/index.md` как entrypoint run-демо.
  - обновляет `links.json` (single source of truth по артефактам run).
- Weekly/monthly human rollups:
  - `scripts/build_weekly_pack.py` -> `reports/L2_mgmt/weekly_<YYYY_WW>/weekly_summary.md`, `weekly_scorecard.csv`, `weekly_agent_quality.md`
  - `scripts/build_exec_brief.py --run-id <run_id>` -> `reports/L3_exec/<YYYY-MM-DD>/exec_brief.md`

Fail-safe правила:
- Если нет assignment/ab_report → `HOLD_NEED_DATA`.
- Если `UNDERPOWERED` → `HOLD_NEED_DATA`.
- Если guardrail breach → `STOP`.

---

## Общая нотация
- Store: `s` (например, A или B)
- День: `d`
- Заказ: `o`
- Позиция (строка заказа): `i`
- Requested units: `req`
- Fulfilled units: `ful`
- Lost units: `lost = req - ful`
- Цена/себестоимость: `unit_price`, `unit_cogs`

---

# V0 (Step 0) — World & Demand generation

## 1) Day Scenarios (holidays, events, preholiday, weather)
**Что это**  
Генерация дневных сценариев, которые влияют на спрос.

**Алгоритм**  
- Горизонт: `num_days` начиная с `start_date`.
- Кол-во праздников/ивентов масштабируется от годовой нормы:
  - `expected = rate * num_days / 365`
  - `n = floor(expected) + Bernoulli(frac(expected))`
- Праздники/ивенты выбираются как **уникальные** даты в горизонте (равномерно).
- `is_preholiday = 1`, если следующий день — праздник.
- Сезон определяется по месяцу:
  - winter: Dec/Jan/Feb
  - spring: Mar/Apr/May
  - summer: Jun/Jul/Aug
  - fall: Sep/Oct/Nov

**Где в коде**  
`ScenarioGenerator.generate_day_scenarios()` в `generate_raw.py`

**Интерпретация**  
Дни отличаются по спросу из‑за календаря и погоды.

**Параметры**  
`holidays_per_year`, `events_per_year` (в `GlobalConfig`)

---

## 2) Weather (weather_bad)
**Что это**  
Плохая погода как бинарный фактор спроса.

**Алгоритм**  
Для каждого дня независимый Bernoulli, вероятность по сезону:  
- winter: 0.50
- spring: 0.35
- summer: 0.10
- fall: 0.35

**Где в коде**  
`WEATHER_BAD_PROB_BY_SEASON` + `ScenarioGenerator.generate_day_scenarios()`

**Интерпретация**  
Плохая погода повышает спрос (в коэффициентах дня).

**Параметры**  
`m_weather_bad` в `DemandConfig`

---

## 3) Scenario type + intensity
**Что это**  
Тип дня и сила эффекта.

**Алгоритм**  
`scenario_type`:
- `normal` если флагов нет
- `combined` если флагов > 1
- иначе: `holiday | preholiday | weather_bad | local_event`

`intensity`:
- для `normal`: 1.0
- иначе Uniform `[1.05..1.60]`

**Где в коде**  
`ScenarioGenerator.generate_day_scenarios()`

**Интерпретация**  
Интенсивность усиливает эффект дня.

**Параметры**  
`intensity_min`, `intensity_max` в `DemandConfig`

---

## 4) Intraday shocks (внутридневные всплески)
**Что это**  
Короткие шоки спроса (demand‑only).

**Алгоритм**  
Генерируются **только** если `local_event=1` или `weather_bad=1`:
- старт: случайный час `[10..20]` + случайная минута
- длительность: `[30..180]` минут
- интенсивность: `[1.10..1.60]`
- `shock_class` всегда `demand`
- `affected_store`:
  - если `allow_store_specific_shocks=False` → `both`
  - иначе A/B/both с p=[0.4,0.4,0.2]

**Где в коде**  
`IntradayShockGenerator.generate_shocks()`

**Интерпретация**  
Кратковременные всплески спроса (погода/ивенты).

---

## 5) Time factors (demand_multiplier)
**Что это**  
Сетка факторов спроса по времени.

**Алгоритм**  
Сетка `ts` (шаг 15 или 60 минут):
- `hourly_multiplier = hourly_curve[hour]`
- `day_multiplier` = произведение флагов:
  - `m_weekend`, `m_holiday`, `m_preholiday`, `m_weather_bad`, `m_local_event_base` × `intensity`
- `shock_multiplier` = intensity если ts попадает в demand‑шок, иначе 1.0
- `demand_multiplier = hourly_multiplier * day_multiplier * shock_multiplier`

**Где в коде**  
`TimeFactorGenerator.generate_time_factors()`

**Интерпретация**  
Комбинация суточного паттерна + календарь + шоки.

---

## 6) Orders stream (Poisson process)
**Что это**  
Генерация числа заказов по минутам.

**Алгоритм**  
На каждой минуте и для каждого store:
- `lambda = base_rate_per_min * popularity_multiplier * demand_multiplier_at_minute`
- `lambda` ограничивается `lambda_cap`
- `n_orders ~ Poisson(lambda)`

**Floor top‑up**  
Если в day-store заказов < `min_orders_per_day_per_store`:
- добавляем top‑up до минимума
- минуты выбираются по весам `hourly_curve`
- `is_floor_fill=1`

**Где в коде**  
`OrderStreamGenerator.generate_orders()`

**Параметры**  
`base_order_rate_per_min`, `lambda_cap`, `min_orders_per_day_per_store`

---

## 7) Customers
**Что это**  
Сегментация и активность клиентов.

**Алгоритм**  
- сегменты: `segment_probs` (low/mid/high)
- `activity_weight`: lognormal → нормируется на сумму
- `initial_status`: первые N = active, остальные = reserve
- `home_store_id`: детерминированное распределение через RNG (по умолчанию 50/50 A/B)

**Где в коде**  
`generate_customers()`

**Интерпретация**  
Базовый “пул” клиентов + исходный статус для V1.1‑Lite.

---

## 8) Basket + Order items
**Что это**  
Как формируется корзина и позиции.

**Алгоритм**  
- `basket_size`: 1..12 по `basket_size_probs`
- `qty`: 1..3 по `qty_probs`
- `units_total = sum(qty)`
- доля perishables по сегментам:
  - low 0.20, mid 0.30, high 0.35
- выбор SKU по **segment‑aware weights**:
  - базовый вес = `popularity_weight`
  - `price_tier` по глобальным квантилям (0.33/0.66)
  - `seg_price_factor` × `seg_cat_factor`
- **Consistency guarantees**:
  - `basket_size == count(items)`
  - `units_total == sum(qty)`

**Где в коде**  
`generate_order_items()`, `_build_segment_weights()`

---

## 9) Prices / COGS / Discount
**Что это**  
Цены и себестоимость на уровне SKU.

**Алгоритм**  
- `list_price` ~ Uniform по диапазону категории (`CATEGORY_PRICE_RANGES`)
- `unit_cogs = list_price * Uniform(cogs_ratio_range)`
- инвариант: `unit_cogs < list_price`
- `discount_pct = 0.0` в Step0

**Где в коде**  
`generate_products()`

---

## 10) Initial inventory
**Что это**  
Стартовые остатки.

**Алгоритм**  
- На основе popularity_weight относительно max
- non‑perish: `[init_qty_min..init_qty_max]`
- perish: `[0.2*min .. 0.8*max]`
- + шум `Uniform[0.8..1.2]`

**Где в коде**  
`generate_initial_inventory()`

---

## 11) Determinism (Step0)
**Что это**  
Одинаковый seed → одинаковый мир.

**Как**  
Отдельные RNG потоки: `rng_world`, `rng_products`, `rng_scenarios`, `rng_shocks`, `rng_orders`, `rng_items`, `rng_inventory`, `rng_customers`.

---

# V1 (Step 1) — Fulfillment simulation

## 1) Inventory physics
**Что это**  
Складское состояние по `(store_id, product_id)`.

**Алгоритм**  
- `fulfilled = min(requested, on_hand)`
- `lost = requested - fulfilled`
- `on_hand -= fulfilled`
- `is_oos = 1 if lost > 0 else 0`

**Где в коде**  
`run_simulation_v1.py` (main loop)

---

## 2) Replenishment baseline
**Что это**  
Ежедневное пополнение “до цели”.

**Алгоритм**  
- target_stock = `initial_qty * factor`
  - perishables: `perish_factor` (default 0.6)
  - non‑perish: `nonperish_factor` (default 1.0)
- срабатывает **на смене даты для store**
- логируется в `step1_replenishment_log`

**Где в коде**  
`_load_initial_inventory()`, `_replenish_for_date()`

---

## 3) Step1 outputs
**Что это**  
Фактические продажи, потери и агрегаты по заказам.

**Алгоритм**  
- `step1_order_items`: строки с fulfilled/lost/GMV/GP
- `step1_orders`: агрегация по заказу
  - `order_gmv`, `order_gp`
  - `order_fill_rate_units = fulfilled_units / requested_units`

**Где в коде**  
`INSERT INTO step1_orders ... GROUP BY order_id`

---

## 4) Elasticity uplift (V1.2, если включено)
**Что это**  
Увеличение реализованного спроса в Step1 на уровне строк заказа (без изменения Step0).

**Алгоритм**  
- Базовый спрос: `requested_qty_base` из RAW.
- Если `enable_elasticity=1` и `elasticity_model=linear`:
  - `uplift_mult = 1 + k_segment * discount_pct`
  - ограничение: `[elasticity_min_mult, elasticity_cap_mult]`
  - `requested_qty_adj = ceil(requested_qty_base * uplift_mult)`
- `requested_qty` в Step1 = `requested_qty_adj` (именно он идет в fill-rate).

**Где в коде**  
`run_simulation_v1.py` (main loop, расчёт `requested_qty_base/adj`, `elasticity_mult`, `elasticity_k`)

**Интерпретация**  
Step0 задает потенциальный спрос, Step1 моделирует реализованный спрос при ценовом воздействии.

---

## 5) Horizon control (7 дней по умолчанию)
**Что это**  
Ограничение горизонта Step1 без перегенерации RAW.

**Алгоритм**  
- Параметр `--horizon-days`:
  - `7` по умолчанию
  - `0` = полная история
- При `>0` берется `start_date = MIN(raw.raw_order_items.date)` и фильтр по `oi.date BETWEEN start_date AND end_date`.

**Где в коде**  
`run_simulation_v1.py` (построение SQL фильтра перед chunk-циклом)

---

# V1.1‑Lite — Customer Dynamics (если включено)

## 1) Active mask
**Что это**  
Заказы неактивных клиентов игнорируются в Step1.

**Алгоритм**  
- если `enable_customer_dynamics=1`
- `customer_id` должен быть active для `home_store_id`
- иначе строка заказа пропускается

**Где в коде**  
`if not dynamics_manager.is_active(...): continue`

---

## 2) Store‑level reputation (EMA)
**Что это**  
Репутация магазина как EMA от качества сервиса.

**Алгоритм**  
- `daily_fill_rate = fulfilled_units / requested_units` по store‑day
- `rep = (1 - alpha) * rep + alpha * daily_fill_rate`

**Где в коде**  
`CustomerDynamicsManager.end_of_day()`

---

## 3) Churn (Bernoulli)
**Что это**  
Вероятностный уход активных клиентов.

**Алгоритм**  
- `churn_prob_store = base + (1 - rep) * sensitivity`
- для каждого active: `p_leave = churn_prob_store * segment_multiplier`
- churn по Bernoulli
- если churn > cap → случайная подвыборка до cap
- floor: активных не меньше `min_active_floor`

**Где в коде**  
`CustomerDynamicsManager.end_of_day()`

**Логи**  
- `step1_customer_events`: event_type=`churn`, reason=`rep_update`, value=`rep`, value2=`churn_prob`

---

## 4) Acquisition (опционально)
**Что это**  
Активация клиентов из reserve.

**Алгоритм**  
- включается флагом `--enable-acquisition=1`
- если `rep >= acq_fill_threshold`
- FIFO из reserve по `home_store_id`
- cap: `max_new_per_day`

**Логи**  
- event_type=`activate`, reason=`rep_high`

---

# Non‑goals / Guardrails
- Step0 demand‑only не меняется (нет обратной связи из Step1).
- Нет генерации заказов в Step1.
- Детерминизм: одинаковый seed/run_id → идентичный результат.
- Runtime не делает DDL: schema/views/privileges ставятся отдельными admin-скриптами.

---

# Changelog
- 2026‑02‑09: файл обновлён под текущий код (V0 + V1 + V1.1‑Lite). Добавлены home_store_id, initial_status, active mask, EMA churn, customer logs.
- 2026‑02‑16: добавлены V1.2 elasticity uplift, `--horizon-days`, admin/runtime guardrails и DQ clean-layer контекст.
