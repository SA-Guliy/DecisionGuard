# DB Schema Reference Screenshots

Moved from project root to reduce clutter.

Files:
- `darkstore - darkstore - raw.png`
- `darkstore - darkstore - step1.png`

These are visual reference snapshots (not runtime inputs).
